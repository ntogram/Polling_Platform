from django.shortcuts import render
from poll_app.models import Polls,Queries,RangeQueries,QueriesOfPolls,RangeQueriesStatistics,AnswersOfQueries,AnswersOfRangeQueries,AnswersSeqQueries,AnswersSeqRangeQueries
from poll_app.forms import CreatePollForm,SearchPollForm
from django.db.models import Q
from django.shortcuts import redirect
from django.urls import reverse

from django.db.models import Sum
from django.utils import timezone
from statistics import pstdev,mean
from  math import pow,sqrt
from numpy import arange,array,where,size
from numpy.random import random_sample,randint
from django.db import IntegrityError
from django.http import JsonResponse
from collections import Counter
# importing datetime module 
from datetime import datetime
# Create your views here.
def homepage(request):
    return render(request,'poll_app/homepage.html')  


def show_create_poll(request):
    
    return render(request,'poll_app/create_poll.html')  

def show_search_poll(request):
    #args={}
    #args.update(csrf((request)))
    return render(request,'poll_app/search_poll.html') 

def  queries_section(request):
     #context={"error_message":"There is a problem. Poll Creation failed"}
     #print("error")
     #return HttpResponse('entered text:' + request.POST['name'])
     #return render(request,'poll_app/homepage.html') 
     #return render(request, 'poll_app/create_poll.html', context)

   
    form= CreatePollForm(request.POST or None)
    print(request.POST['start_date'])
    category=request.POST['category']
    categories=['Politics', 'Social', 'Environment','Economics-Business','Science','Technology','Culture','Music-Dance','Theater-Cinema','Sports','Food-Drinks','Hobbies']
   # print("DEBUG:"+str(form.errors))
    if (form.is_valid()  and category in categories):
        form.save()
        name=request.POST["name"];
        context={"title":name};
        return render(request, 'poll_app/queries_section.html', context)
    else:
        context={"error_message":"There is a problem. Poll Creation failed"}
        return render(request, 'poll_app/create_poll.html', context)



#Confidence Interval 95% using  the Adjusted Wald Method
def  calc_confidence_interval(fraction,count,z):
    if(count==None or count==0):
        confidence_interval={"limit_down":0.00,"limit_up":0.00}
        return confidence_interval
    nadj=count+(pow(z,2))
    padj=((count*fraction)+((pow(z,2))/2))/nadj
    limit_down=round(padj-z*sqrt(padj*(1-padj)/nadj),2)
    limit_up=round(padj+z*sqrt(padj*(1-padj)/nadj),2)
    if(limit_down<0):
        limit_down=0.00
    if(limit_up>1):
        limit_up=1.00
    confidence_interval={"limit_down":limit_down,"limit_up":limit_up}
    return confidence_interval
#Confidence Interval 95% for mean value
def  calc_confidence_intervalm(mean_val,std_val,count,z):
    if(count==None or count==0):
        confidence_interval={"limit_down":0.00,"limit_up":0.00}
        return confidence_interval
    std_error=std_val/sqrt(count)
    margin_error=z*std_error
    limit_down=round(mean_val-margin_error,2)
    limit_up=round(mean_val+margin_error,2)
   
    confidence_interval={"limit_down":abs(limit_down),"limit_up":abs(limit_up)}
    
    return confidence_interval


def finddecimalpointcount(a):
    s=str(a)
    pos=[pos for pos, char in enumerate(s) if char =='.']
    c=s[pos[0]+1:len(s)]
    return len(c)
def truncatenum(a,n):
    if n==0:
        return int(a)
    s=str(a)
    pos=[pos for pos, char in enumerate(s) if char =='.']
    b=s[0:pos[0]+n+1]
    c=float(b)
    return c

def checkzscore(pa,pb,na,nb):
    #print(pa)
    #print(pb)
    #print(na)
    #print(nb)
    if (pa==0 or  pb==0 or na==0 or nb==0):
            return  False
    numerator=abs(pa-pb)
    p1=pa*(1-pa)
    p2=pb*(1-pb)
    n1=p1/na
    n2=p2/nb
    n=n1+n2
    denominator=sqrt(n)
    z_score=numerator/denominator
    #alpha=0.05,k=2,threshold=2.1783
    #thresholds=[1.96,2.1783,2.2894,2.3613,2.4131,2.4532,2.4854,2.5123,2.5352,2.555,2.5724,2.5879,2.6019,2.6145,2.6261,2.6367,2.6465,2.6556,2.664,2.672,1.6794,2.6864,2.693,2.6993,2.7052]
    threshold=2.1783
    print(z_score)
    if (z_score>threshold):
        return True
    else:
        return False



def show_stats(request):
    try:
        name=request.POST["poll_name"]; 
        poll=(Polls.objects.get(name=name))
        idp=poll.idp
    except:
         context={"error_message":"There is a  problem. Query not exist"}
         return render(request,'poll_app/answer_poll.html',context)
    idqs=QueriesOfPolls.objects.filter(idp=idp)
    idqrs=RangeQueriesStatistics.objects.filter(idp=idp)
    record_answers=[]
    queries=[]
    z=1.96#95%
    for item in idqrs:
            range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
            stat_data=RangeQueriesStatistics.objects.get(idp=idp,idqr=(item.idqr).idqr)
            total=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr).aggregate(Sum('count'))
           
            mconfindence_interval=calc_confidence_intervalm(stat_data.avg,stat_data.std,total['count__sum'],z)
            dp=finddecimalpointcount(range_query.step_val)
            if(range_query.number_answers=='only one answer'):
                graph_type='column'
                range1=(range_query.max_val-range_query.min_val)/range_query.step_val
                if(range1<=10):
                       

                        for i in arange(range_query.min_val,range_query.max_val+range_query.step_val,range_query.step_val):
                            aswr=truncatenum(i,dp)
                            try:
                                answer=AnswersOfRangeQueries.objects.get(idp=idp,idqr=(item.idqr).idqr,answer=aswr)
                                confidence_interval=calc_confidence_interval(answer.percentage,total['count__sum'],z)
                                record_answer={"answer":answer.answer,"count":answer.count,"percentage":answer.percentage,"confidence_interval":confidence_interval}
                         
                            except  AnswersOfRangeQueries.DoesNotExist:
                                confidence_interval=calc_confidence_interval(0.0,total['count__sum'],z)
                                record_answer={"answer":str(aswr),"count":0,"percentage":0.0,"confidence_interval":confidence_interval}
                            record_answers.append(record_answer)
                        record={"query":range_query.range_query,"kind":"range_query","graph_type":graph_type,"record_answers":record_answers,"mconfindence_interval":mconfindence_interval}
                else:
                        step=(range_query.max_val-range_query.min_val)/10
                        if(range_query.type=="integer"):
                            step=int(step)+1
                        #dp=finddecimalpointcount(step)
                        #if (step!=int(step)):
                        #    step=int((range_query.max_val-range_query.min_val)/10)+1
                        
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for k in arange(range_query.min_val,range_query.max_val+step,step):
                            if(limit_up==range_query.max_val):
                                 count=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr,answer__lte=limit_up,answer__gte=limit_down).aggregate(Sum('count'))
                            else:
                                count=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr,answer__lt=limit_up,answer__gte=limit_down).aggregate(Sum('count'))
                            if count['count__sum']==None:
                                count['count__sum']=0
                                percentage=0
                            else:
                                percentage=count['count__sum']/total['count__sum'] 
                            confidence_interval=calc_confidence_interval(percentage,total['count__sum'],z)
                            
                            record_answer={"answer":str(truncatenum(limit_down,dp))+"-"+str(truncatenum(limit_up,dp)),"count":count['count__sum'],"percentage":percentage,"confidence_interval":confidence_interval}
                            record_answers.append(record_answer)
                            limit_down=limit_down+step
                            limit_up=limit_up+step
                            
                        record={"query":range_query.range_query,"kind":"range_query","graph_type":graph_type,"record_answers":record_answers,"mconfindence_interval":mconfindence_interval}
            else:
                 graph_type='bar'
                 
                 for i in arange(range_query.min_val,range_query.max_val+range_query.step_val,range_query.step_val):
                            aswr=truncatenum(i,dp)
                            
                            try:
                                answer=AnswersOfRangeQueries.objects.get(idp=idp,idqr=(item.idqr).idqr,answer=aswr)
                                #queries votes
                                rst=RangeQueriesStatistics.objects.get(idp=idp,idqr=(item.idqr).idqr)
                                confidence_interval=calc_confidence_interval(answer.percentage,rst.qvotes,z)
                                record_answer={"answer":answer.answer,"count":answer.count,"percentage":answer.percentage,"confidence_interval":confidence_interval}
                         
                            except  AnswersOfRangeQueries.DoesNotExist:
                                 #queries votes
                                rst=RangeQueriesStatistics.objects.get(idp=idp,idqr=(item.idqr).idqr)
                                confidence_interval=calc_confidence_interval(0,rst.qvotes,z)
                                record_answer={"answer":str(aswr),"count":0,"percentage":0.0,"confidence_interval":confidence_interval}
                            record_answers.append(record_answer)
                  
                 record={"query":range_query.range_query,"kind":"range_query","graph_type":graph_type,"record_answers":record_answers,"mconfindence_interval":mconfindence_interval}
            record_answers=[]
            queries.append(record)
            

    for item in idqs:
        query=Queries.objects.get(pk=(item.idq).idq)
        answers=AnswersOfQueries.objects.filter(idp=idp,idq=(item.idq).idq)
        total=AnswersOfQueries.objects.filter(idp=idp,idq=(item.idq).idq).aggregate(Sum('count'))
        if(query.number_answers=='only one answer'):
                graph_type='column'
                
        else:
            graph_type='bar'
        for query_answer in answers:
            if(graph_type=="column"):
                confidence_interval=calc_confidence_interval(query_answer.percentage,total['count__sum'],z)
            else:
                #queries votes
                qop=QueriesOfPolls.objects.get(idp=idp,idq=(item.idq).idq)
                confidence_interval=calc_confidence_interval(query_answer.percentage,qop.qvotes,z)
            record_answer={"answer":query_answer.answer,"count":query_answer.count,"percentage":query_answer.percentage,"confidence_interval":confidence_interval}
            record_answers.append(record_answer)
        record={"query":query.query,"kind":"query","graph_type":graph_type,"record_answers":record_answers}
        record_answers=[]
        queries.append(record)
    context={"queries":queries,"poll_name":name}
    return render(request,'poll_app/poll_stats.html',context)




def submit_answers(request):
    stat_check=2 #Choose 1 or 2
    try:
        name=request.POST["poll_name"];
        poll=(Polls.objects.get(name=name))
        idp=poll.idp
       
    except:
         context={"error_message":"There is a  problem. Poll not exist"}
         return render(request,'poll_app/answer_poll.html',context)
    field_names=list((request.POST).keys())
    print(field_names)
    queries_fields = [i for i in field_names if i.startswith('question')]
    print(queries_fields)
    answer_fields=[i for i in field_names if i.startswith('answer')]
    rangequeries_fields=[i for i in field_names if i.startswith('range_question')]
    print(rangequeries_fields)
    rangeanswer_fields=[i for i in field_names if i.startswith('range_answer')]
    for i in  range(len(queries_fields)):
        query_field="question"+str(i+1)
        print(query_field) 
        if query_field in queries_fields:
            query_val=request.POST[query_field]
           
            try:
                query=Queries.objects.get(query=query_val)
            except Queries.DoesNotExist:
                context={"error_message":"There is a  problem. Query not exist"}
                return render(request,'poll_app/answer_poll.html',context)
            idq=query.idq
            type=query.number_answers;

            if(type=='only one answer'):
                 answer_field="answer"+str(i+1)
                 if answer_field in answer_fields:
                     answer_val=request.POST[answer_field]
                     try:
                        answer_record=AnswersOfQueries.objects.get(idp=idp,idq=idq,answer=answer_val)
                     except AnswersOfQueries.DoesNotExist:
                        context={"error_message":"There is a problem. Answer not exist"}
                        return render(request,'poll_app/answer_poll.html',context)
                     answer_record.count=answer_record.count+1
                     answer_record.save()
                     total=AnswersOfQueries.objects.filter(idp=idp,idq=idq).aggregate(Sum('count'))
                     answer_record.percentage=answer_record.count/total['count__sum'] 
                     answer_record.save()
                     other_answers=AnswersOfQueries.objects.filter(idp=idp,idq=idq).exclude(answer=answer_val)
                     for a in other_answers:
                         a.percentage=a.count/total['count__sum'] 
                         a.save()
                     qp=QueriesOfPolls.objects.get(idp=idp,idq=idq)
                     qp.qvotes=qp.qvotes+1
                     qp.save()
                     qas=AnswersSeqQueries(idp=poll,idq=query,answer=answer_record.answer)
                     qas.save()
                 else:
                     context={"error_message":"There is a problem. Answer not found"}
                     return render(request,'poll_app/answer_poll.html',context)
            
            
            else:
                answer_field="answer"+str(i+1)
                if answer_field in answer_fields:
                     answer_val_list=request.POST.getlist(answer_field)
                     for answer_val in answer_val_list:
                         try:
                            answer_record=AnswersOfQueries.objects.get(idp=idp,idq=idq,answer=answer_val)
                         except AnswersOfQueries.DoesNotExist:
                            context={"error_message":"There is a problem. Answer not exist"}
                            return render(request,'poll_app/answer_poll.html',context)
                         answer_record.count=answer_record.count+1
                         answer_record.save()
                         qas=AnswersSeqQueries(idp=poll,idq=query,answer=answer_record.answer)
                         qas.save()
                     #total=AnswersOfQueries.objects.filter(idp=idp,idq=idq).aggregate(Sum('count'))
                     #change with queries off  poll vote
                    # total=poll.votes
                     qp=QueriesOfPolls.objects.get(idp=idp,idq=idq)
                     qp.qvotes=qp.qvotes+1
                     qp.save()
                     total=qp.qvotes
                    
                     other_answers=AnswersOfQueries.objects.filter(idp=idp,idq=idq)
                     for a in other_answers:
                         a.percentage=a.count/total
                         print(a.percentage)
                         a.save()
                else:
                     context={"error_message":"There is a problem. Answer not found"}
                     return render(request,'poll_app/answer_poll.html',context)
            #increase queries pf  poll votes
        else:
             context={"error_message":"There is a problem. Query not found"}
             return render(request,'poll_app/answer_poll.html',context)

    for i in  range(len(rangequeries_fields)):       
        rangequery_field="range_question"+str(i+1)
       
        if rangequery_field in rangequeries_fields:
            rangequery_val=request.POST[rangequery_field]
            
            try:
                rangequery=RangeQueries.objects.get(range_query=rangequery_val)
            except RangeQueries.DoesNotExist:
                context={"error_message":"There is a problem. Range Query not exist"}
                return render(request,'poll_app/answer_poll.html',context)
            idqr=rangequery.idqr
            rtype=rangequery.number_answers;
            if(rtype=='only one answer'):
                 rangeanswer_field="range_answer"+str(i+1)
                 print()
                 if rangeanswer_field in rangeanswer_fields:
                     rangeanswer_val=request.POST[rangeanswer_field]
                     try:
                             rangeanswer_record,created=AnswersOfRangeQueries.objects.get_or_create(idp=poll,idqr=rangequery,answer=rangeanswer_val,count=1,percentage=0)
                             print("1")
                     except IntegrityError:
                              rangeanswer_record=AnswersOfRangeQueries.objects.get(idp=poll,idqr=rangequery,answer=rangeanswer_val)
                              rangeanswer_record.count= rangeanswer_record.count+1
                              print("2")
                                                
                    
                     rangeanswer_record.save()
                     qasr=AnswersSeqRangeQueries(idp=poll,idqr=rangequery,answer=rangeanswer_record.answer)
                     qasr.save()
                     ntype=rangequery.type
                     other_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=idqr)
                     population=[]
                     for a in other_answers:
                         for i in range(a.count):
                             population.append(a.answer)
                     rst=RangeQueriesStatistics.objects.get(idp=idp,idqr=idqr)
                     mean_val=mean(population)
                     std_val=pstdev(population)
                     rst.avg=mean_val
                     rst.std=std_val
                     rst.qvotes=rst.qvotes+1
                     rst.save()
                    
                    
                     total=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=idqr).aggregate(Sum('count'))
                     for a in other_answers:
                                a.percentage=a.count/total['count__sum'] 
                                a.save()
                      
                       
                 else:
                    context={"error_message":"There is a problem. Answer of Range Query not found"}
                    return render(request,'poll_app/answer_poll.html',context)
            else:
                rangeanswer_field="range_answers"+str(i+1)
                if rangeanswer_field in rangeanswer_fields:
                     rangeanswer_val=request.POST[rangeanswer_field]
                     rangeanswerlist=rangeanswer_val.split(",")
                     rangeanswerlist=rangeanswerlist[0:len(rangeanswerlist)-1]
                     for range_answer1 in rangeanswerlist:
                          try:
                            rangeanswer_record,created=AnswersOfRangeQueries.objects.get_or_create(idp=poll,idqr=rangequery,answer=range_answer1,count=1,percentage=0)
                          except IntegrityError:
                              rangeanswer_record=AnswersOfRangeQueries.objects.get(idp=poll,idqr=rangequery,answer=range_answer1)
                              rangeanswer_record.count= rangeanswer_record.count+1
                          
                          rangeanswer_record.save()
                          qasr=AnswersSeqRangeQueries(idp=poll,idqr=rangequery,answer=rangeanswer_record.answer)
                          qasr.save()
                          ntype=rangequery.type
                          other_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=idqr)

                          population=[]
                          for a in other_answers:
                                for i in range(a.count):
                                    population.append(a.answer)
                          rst=RangeQueriesStatistics.objects.get(idp=idp,idqr=idqr)
                          mean_val=mean(population)
                          std_val=pstdev(population)
                          rst.avg=mean_val
                          rst.std=std_val
                          rst.qvotes=rst.qvotes+1
                          total=rst.qvotes
                          rst.save()
                       
                    
                    
                          #change rangequerystatistics votes
                         # total=poll.votes
                         # total=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=idqr).aggregate(Sum('count'))
                          for a in other_answers:
                                a.percentage=a.count/total
                                a.save()

                    
                else:
                     context={"error_message":"There is a problem. Answer of Range Query not found"}
                     return render(request,'poll_app/answer_poll.html',context)
             #increase rangequerystatistics votes  
    poll.votes=poll.votes+1     
    poll.save()        
    #check conf val after for polls questions submit answer
    #if all queries and range queries are expired ->poll expired now
    if stat_check==2:
        print("A/B testing")
        svotes=160
        csvotes=svotes/2
        idqs=QueriesOfPolls.objects.filter(idp=idp)
        idqs=QueriesOfPolls.objects.filter(idp=idp).exclude(expired=True)
        idqrs=RangeQueriesStatistics.objects.filter(idp=idp).exclude(expired=True)
        lenqs=len(idqs)
        lenqrs=len(idqrs)
        countqs=0
        countqrs=0
        for item in idqs:
            qvotes=item.qvotes
            if(qvotes%svotes==0 and qvotes>=svotes):
                 answers_count= AnswersOfQueries.objects.filter(idp=idp,idq=(item.idq).idq).count()
                 samples_record=AnswersSeqQueries.objects.filter(idp=idp,idq=(item.idq).idq).order_by('-idas')[0:svotes]
                 for i in range(0,2):
                                 print(str(i+1)+"/2")
                                 team=samples_record[i*csvotes:(i+1)*csvotes]
                                 answer_items=[]
                                 for itemx in team:
                                     answer_items.append(itemx.answer)
                                 samples_datac=Counter(answer_items)
                                 samples_datacount=[]
                                 samples_datapercentage=[]
                                 for value in samples_datac.items():
                                     samples_datacount.append(value[1])
                                     percentage=value[1]/csvotes
                                     samples_datapercentage.append(percentage)
                                 noanaswers=answers_count-len(samples_datacount)
                                 for j in range(noanaswers):
                                     samples_datacount.append(0)
                                     samples_datapercentage.append(0)
                                 checkz=True
                                 for k1 in range(len(samples_datacount)):
                                     if(checkz==False):
                                                break
                                     for k2 in range(k1+1,len(samples_datacount)):
                                         print("z"+str(k1)+str(k2))

                                         checkz=checkzscore(samples_datapercentage[k1],samples_datapercentage[k2],samples_datacount[k1],samples_datacount[k2])
                                         if(checkz==False):
                                                   break
                                 if(checkz==False):
                                                   break 
                 if(checkz==True):
                                 countqs=countqs+1
                                 item.expired=True
                                 item.save()


    
      
        for item in idqrs:
            qvotes=item.qvotes
            if(qvotes%svotes==0 and qvotes>=svotes):
                range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
                range1=(range_query.max_val-range_query.min_val)/range_query.step_val
                samples_record=AnswersSeqRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr).order_by('-idars')[0:svotes]
                dp=finddecimalpointcount(range_query.step_val)
                if(range1<=10):
                   answers_count=int(range1+1)
                   for i in range(0,2):
                       print(str(i+1)+"/2")
                       team=samples_record[i*csvotes:(i+1)*csvotes]
                       answer_items=[]
                       for itemx in team:
                           answer_items.append(itemx.answer)
                       samples_datac=Counter(answer_items)
                       samples_datacount=[]
                       samples_datapercentage=[]
                       percentage=0
                       for value in samples_datac.items():
                           samples_datacount.append(value[1])
                           percentage=value[1]/csvotes
                           samples_datapercentage.append(percentage)
                       noanaswers=answers_count-len(samples_datacount)
                       for j in range(noanaswers):
                            samples_datacount.append(0)
                            samples_datapercentage.append(0)
                       checkz=True
                       for k1 in range(len(samples_datacount)):
                            if(checkz==False):
                                     break
                            for k2 in range(k1+1,len(samples_datacount)):
                                        print("z"+str(k1)+str(k2))
                                        checkz=checkzscore(samples_datapercentage[k1],samples_datapercentage[k2],samples_datacount[k1],samples_datacount[k2])
                                        if(checkz==False):
                                                break
                       if(checkz==False):
                            break
                else:
                    for i in range(0,2):
                        print(str(i+1)+"/2")
                        team=samples_record[i*csvotes:(i+1)*csvotes]
                        answer_items=[]
                        step=((range_query.max_val-range_query.min_val)/10)
                       
                        if(range_query.type=="integer"):
                             step=int(step)+1
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for itemx in team:
                                answer_items.append(itemx.answer)
                        samples_datacount=[]
                        samples_datapercentage=[]
                        percentage=0
                       
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for nx in arange(range_query.min_val,range_query.max_val+step,step):
                            if(limit_up==range_query.max_val):
                                    count = sum(map(lambda x : x<=limit_up and x>=limit_down, answer_items))
                            else:
                                 count = sum(map(lambda x : x<limit_up and x>=limit_down, answer_items))
                            samples_datacount.append(count)
                            percentage=count/csvotes
                            samples_datapercentage.append(percentage)
                            limit_down=limit_down+step
                            limit_up=limit_up+step
                        checkz=True
                        for k1 in range(len(samples_datacount)):
                            if(checkz==False):
                                break
                            for k2 in range(k1+1,len(samples_datacount)):
                                print("z"+str(k1)+str(k2))
                                checkz=checkzscore(samples_datapercentage[k1],samples_datapercentage[k2],samples_datacount[k1],samples_datacount[k2])
                                if(checkz==False):
                                        break
                        if(checkz==False):
                              break

                
                if(checkz==True):
                   countqrs=countqrs+1
                   item.expired=True
                   item.save()
          
        if(countqs==lenqs and countqrs==lenqrs):
            print("end")
            poll.end_date=timezone.now()
            poll.save()
            
        if    "stat_info[]" in     field_names:
            context={"poll_name":name,"statshow":True}
            return render(request,'poll_app/answer_completed.html',context)
        else:
            context={"poll_name":name,"statshow":False}
            return render(request,'poll_app/answer_completed.html',context)      
                                 
                                 
                                 
    z=1.96
    idqs=QueriesOfPolls.objects.filter(idp=idp).exclude(expired=True)
    idqrs=RangeQueriesStatistics.objects.filter(idp=idp).exclude(expired=True)
    lenqs=len(idqs)
    lenqrs=len(idqrs)
    countqs=0
    countqrs=0
    queries=[]
    for item in idqs:
            
          

            query=Queries.objects.get(pk=(item.idq).idq)
            answers=AnswersOfQueries.objects.filter(idp=idp,idq=query.idq)
           
            apantiseis=[]
            total=item.qvotes
            count=0
            conf_list=[]
            if(query.number_answers=='only one answer'):
             for ap in answers:
                #apantiseis.append(ap.answer)
                conf_int=calc_confidence_interval(ap.percentage,total,z)
                l1=[conf_int['limit_down'],count]
                l2=[conf_int['limit_up'],count]
                conf_list.append(l1)
                conf_list.append(l2)
                count=count+1
                apantiseis.append(ap)

             conf_arr=array(conf_list)
             conf_arr=conf_arr[conf_arr[:,0].argsort()]
             ids=conf_arr[:,1]
           
             show=True
             for j in range(0,len(ids),2):
                 if ids[j]!=ids[j+1]:
                                    show=False
                                    break
                 #show=False
                 #break
                    #if ids[j]!=ids[j+1]:
                    #         val=conf_arr[j+1,0]
                    #         indexes=where(conf_arr[:,0] == val)
                    #         for k in range(size(indexes,1)):
                    #             if(indexes[0][k]!=j+1):
                    #                if(ids[indexes[0][k]]!=ids[j]):
                    #                        show=False
                    #                else:
                    #                        show=True
                    #         if (show==False):
                    #                    break
             if show==False or total==0:
                     question_info={"query":query.idq,"type":query.number_answers,"answers":apantiseis,"qp":item}
                     queries.append(question_info)
             else:
                countqs=countqs+1
                item.expired=True
                item.save()
                continue
            else:
                if(query.number_answers=='many answers'):
                     show=True
                     
                     recor={}
                     for ap in answers:
                          apantiseis.append(ap)
                          if show==False:
                              continue
                          conf_int=calc_confidence_interval(ap.percentage,total,z)
                          l1=[conf_int['limit_down'],0]
                          l2=[conf_int['limit_up'],0]
                          recor[ap.answer]=conf_int
                          conf_list.append(l1)
                          conf_list.append(l2)
                          conf_int=calc_confidence_interval(1-ap.percentage,total,z)
                          l1=[conf_int['limit_down'],1]
                          l2=[conf_int['limit_up'],1]
                          recor["not "+ap.answer]=conf_int
                          
                          conf_list.append(l1)
                          conf_list.append(l2)
                          conf_arr=array(conf_list)
                          conf_arr=conf_arr[conf_arr[:,0].argsort()]
                          ids=conf_arr[:,1]
                          for j in range(0,len(ids),2):
                                if ids[j]!=ids[j+1]:
                                    show=False
                                    
                          conf_list=[]
                     
                     for keys,values in recor.items():
                                print(keys)
                                print(values)
                                
                     if show==False or total==0:
                         question_info={"query":query.idq,"type":query.number_answers,"answers":apantiseis,"qp":item}
                         queries.append(question_info)
                     else:
                            countqs=countqs+1
                            item.expired=True
                            item.save()
                            continue
        #else:
    range_queries=[]
    for item in idqrs:
          range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
          range_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr)
          total=item.qvotes
          count=0
          conf_list=[]
          dp=finddecimalpointcount(range_query.step_val)
          if(range_query.number_answers=='only one answer'):
            range1=(range_query.max_val-range_query.min_val)/range_query.step_val
            if(range1<=10):
                        
                        for i in arange(range_query.min_val,range_query.max_val+range_query.step_val,range_query.step_val):
                            aswr=truncatenum(i,dp)
                            try:
                                answer=AnswersOfRangeQueries.objects.get(idp=idp,idqr=(item.idqr).idqr,answer=aswr)
                                conf_int=calc_confidence_interval(answer.percentage,total,z)
                            except  AnswersOfRangeQueries.DoesNotExist:
                                conf_int=calc_confidence_interval(0.0,total,z)
                            l1=[conf_int['limit_down'],count]
                            l2=[conf_int['limit_up'],count]
                            conf_list.append(l1)
                            conf_list.append(l2)
                            count=count+1
            else:
                        step=((range_query.max_val-range_query.min_val)/10)
                        
                        if(range_query.type=="integer"):
                             step=int(step)+1
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for k in arange(range_query.min_val,range_query.max_val+step,step):
                            if(limit_up==range_query.max_val):
                                 countr=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr,answer__lte=limit_up,answer__gte=limit_down).aggregate(Sum('count'))
                            else:
                                countr=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr,answer__lt=limit_up,answer__gte=limit_down).aggregate(Sum('count'))
                            if countr['count__sum']==None:
                                countr['count__sum']=0
                            if total!=0:
                                percentage=countr['count__sum']/total 
                            else:
                                 percentage=0
                            conf_int=calc_confidence_interval(percentage,total,z)
                            l1=[conf_int['limit_down'],count]
                            l2=[conf_int['limit_up'],count]
                            conf_list.append(l1)
                            conf_list.append(l2)
                            count=count+1
                            limit_down=limit_down+step
                            limit_up=limit_up+step
          else:
              
               for i in arange(range_query.min_val,range_query.max_val+range_query.step_val,range_query.step_val):
                            aswr=truncatenum(i,dp)
                            try:
                                answer=AnswersOfRangeQueries.objects.get(idp=idp,idqr=(item.idqr).idqr,answer=aswr)
                                #queries votes
                                rst=RangeQueriesStatistics.objects.get(idp=idp,idqr=(item.idqr).idqr)
                                conf_int=calc_confidence_interval(answer.percentage,total,z)
                            except  AnswersOfRangeQueries.DoesNotExist:
                                 #queries votes
                                 conf_int=calc_confidence_interval(0,total,z)
                            l1=[conf_int['limit_down'],count]
                            l2=[conf_int['limit_up'],count]
                            conf_list.append(l1)
                            conf_list.append(l2)
                            count=count+1
          conf_arr=array(conf_list)
          #print(conf_arr)
          #print("-------------------------")
          conf_arr=conf_arr[conf_arr[:,0].argsort()]
          ids=conf_arr[:,1]
          print(conf_arr)
          #print("-------------------------")
          show=True
          for j in range(0,len(ids),2):
                    if ids[j]!=ids[j+1]:
                        show=False
                        break
                        #val=conf_arr[j+1,0]
                        #indexes=where(conf_arr[:,0] == val)
                        #for k in range(size(indexes,1)):
                        #     if(indexes[0][k]!=j+1):
                        #        if(ids[indexes[0][k]]!=ids[j]):
                        #                    show=False
                        #        else:
                        #                     show=True
                        #if (show==False):
                        #        break
          if show==False  or total==0:
            question_info={"rangequery":range_query,"rst":item}
            range_queries.append(question_info)
         
          else:
                countqrs=countqrs+1
                item.expired=True
                item.save()
                continue
    if(countqs==lenqs and countqrs==lenqrs):
        print("end")
        poll.end_date=timezone.now()

    if    "stat_info[]" in     field_names:
        context={"poll_name":name,"statshow":True}
        return render(request,'poll_app/answer_completed.html',context)
    else:
        context={"poll_name":name,"statshow":False}
        return render(request,'poll_app/answer_completed.html',context)            
                     
                     
                     
                     
                     
                     
                     
                     


                     
                     
   

def  finish(request):
     name=request.POST["poll_name"];
     if(name.endswith(" ") ):
         name=name[0:len(name)-1]
     #print(type(name))
     #myname='Fanta Poll'
     count=0
     for i in name:
         print(str(count)+i)
         count=count+1
      
     #print(str(myname==name))
     poll=(Polls.objects.get(name=name))
     idp=poll.idp
     field_names=list((request.POST).keys())
     list_queries=(request.POST["queries_ids"]).split(",")
     elem=[]
     currentqueries_ids=[]
     currentrangequeries_ids=[]
     for x in range(len(list_queries)-1):
         print(str(x)+"time")
         elem=list_queries[x].split(":")
         id=elem[1]
         mytype=elem[0]
         noanswer=request.POST['noanswer'+id]
         myquery=request.POST['query'+id]
         if (elem[0]=='textual multiple choice question'):
             if(Queries.objects.count()==0):
                 #print("block 1")
                 #query votes
                 q=Queries(query=myquery,number_answers=noanswer)
                 q.save()
                 #queries of polls vote 
                 qp=QueriesOfPolls(idp=poll,idq=q,qvotes=0,expired=False)
                 qp.save()
                 currentqueries_ids.append(q.idq)
             else:
                 #print("block 2")
                 q,nocreated=Queries.objects.get_or_create(query=myquery,number_answers=noanswer)
                 if(nocreated==True):
                     #print("block_2_1")
                     q.save()
                      #queries of polls vote 
                     qp=QueriesOfPolls(idp=poll,idq=q,qvotes=0,expired=False)
                     qp.save()
                     currentqueries_ids.append(q.idq)
                 else:
                     #print("block_2_2")
                     try:
                            qp,rnocreated=QueriesOfPolls.objects.get_or_create(idp=poll,idq=q,qvotes=0,expired=False)
                     except:
                          context={"error_message":"There is a problem.Some queries are duplicated. Queries are not added in the poll","title":name}
                          for item in currentqueries_ids:
                             print("q "+str(item)+"p "+str(poll.idp))
                             QueriesOfPolls.objects.filter(idp=poll.idp,idq=item).delete()
                             AnswersOfQueries.objects.filter(idp=poll.idp,idq=item).delete()
                          for item in currentrangequeries_ids:
                
                             RangeQueriesStatistics.objects.filter(idp=poll.idp,idqr=item).delete()
                     if(rnocreated==True):
                          #queries of polls vote 
                          qp.save()
                          currentqueries_ids.append(q.idq)
                     else:
                         #print("block_2_2_2")
                         context={"error_message":"There is a problem.Some queries are duplicated. Queries are not added in the poll","title":name}
                         print(len(currentqueries_ids))
                         for item in currentqueries_ids:
                             print("q "+str(item)+"p "+str(poll.idp))
                             QueriesOfPolls.objects.filter(idp=poll.idp,idq=item).delete()
                             AnswersOfQueries.objects.filter(idp=poll.idp,idq=item).delete()
                         for item in currentrangequeries_ids:
                
                             RangeQueriesStatistics.objects.filter(idp=poll.idp,idqr=item).delete()
                             
                         return render(request, 'poll_app/queries_section.html', context)
                         
                
             answer_start="answer"+id+"_"
             answer_tags=[i for i in field_names if i.startswith(answer_start)]
             print(len(answer_tags))
             for item in answer_tags:
                 myanswer=request.POST[item]
                 print("block3")
                 try:
                    qa,anocreated=AnswersOfQueries.objects.get_or_create(idp=poll,idq=q,answer=myanswer,count=0,percentage=0.0)
                 except:
                     context={"error_message":"There is a problem.Some answers in some queries are duplicated. Queries are not added in the poll","title":name}
                     for item in currentqueries_ids:
                             print("q "+str(item)+"p "+str(poll.idp))
                             QueriesOfPolls.objects.filter(idp=poll.idp,idq=item).delete()
                             AnswersOfQueries.objects.filter(idp=poll.idp,idq=item).delete()
                     for item in currentrangequeries_ids:
                
                             RangeQueriesStatistics.objects.filter(idp=poll.idp,idqr=item).delete()
                     return render(request, 'poll_app/queries_section.html', context)
                 print("s:"+str(anocreated))
                 if(anocreated==True):
                     print("block3_1")
                     #qa.count=0;
                     #qa.percentage=0;
                     qa.save()
                 else:
                    print("block3_2")
                    print(len(currentqueries_ids))
                    context={"error_message":"There is a problem.Some answers in some queries are duplicated. Queries are not added in the poll","title":name}
                    for item in currentqueries_ids:
                             print("q "+str(item)+"p "+str(poll.idp))
                             QueriesOfPolls.objects.filter(idp=poll.idp,idq=item).delete()
                             AnswersOfQueries.objects.filter(idp=poll.idp,idq=item).delete()
                    for item in currentrangequeries_ids:
                
                             RangeQueriesStatistics.objects.filter(idp=poll.idp,idqr=item).delete()
                    return render(request, 'poll_app/queries_section.html', context)
                         
                    



         else:
                number_type=request.POST['numbertype'+id]
                step_val=request.POST['stepval'+id]
                min_val=request.POST['minval'+id]
                max_val=request.POST['maxval'+id]
                if(RangeQueries.objects.count()==0):
                        idqr=1
                        qr=RangeQueries(range_query=myquery,number_answers=noanswer,type=number_type,min_val=min_val,max_val=max_val,step_val=step_val)
                        qr.save()
                        #range queries statistics vote
                        qpr=RangeQueriesStatistics(idp=poll,idqr=qr,avg=0,std=0,qvotes=0,expired=False)
                        qpr.save()
                        currentrangequeries_ids.append(qr.idqr)
                else:
                         qr,nocreatedqr=RangeQueries.objects.get_or_create(range_query=myquery,number_answers=noanswer,type=number_type,min_val=min_val,max_val=max_val,step_val=step_val)
                         if(nocreatedqr==True):
                                 qr.save()
                                 #range queries statistics vote
                                 qpr=RangeQueriesStatistics(idp=poll,idqr=qr,avg=0,std=0,qvotes=0,expired=False)
                                 qpr.save()
                                 currentrangequeries_ids.append(qr.idqr)
                         else:
                                    try:
                                          #range queries statistics vote
                                        qpr,qprnocreated=RangeQueriesStatistics.objects.get_or_create(idp=poll,idqr=qr,avg=0,std=0,qvotes=0,expired=False)
                                    except:
                                             context={"error_message":"There is a problem.Some queries are duplicated. Queries are not added in the poll","title":name}
                                             for item in currentqueries_ids:
                
                                                    QueriesOfPolls.objects.filter(idp=poll.idp,idq=item).delete()
                                                    AnswersOfQueries.objects.filter(idp=poll.idp,idq=item).delete()
                                             for item in currentrangequeries_ids:
                
                                                    RangeQueriesStatistics.objects.filter(idp=poll.idp,idqr=item).delete()
                                             return render(request, 'poll_app/queries_section.html', context)
                                    if(qprnocreated==True):
                                        qpr.save()
                                        currentrangequeries_ids.append(qr.idqr)
                                    else:
                                       context={"error_message":"There is a problem.Some queries are duplicated. Queries are not added in the poll","title":name}
                                       for item in currentqueries_ids:
                
                                            QueriesOfPolls.objects.filter(idp=poll.idp,idq=item).delete()
                                            AnswersOfQueries.objects.filter(idp=poll.idp,idq=item).delete()
                                       for item in currentrangequeries_ids:
                
                                            RangeQueriesStatistics.objects.filter(idp=poll.idp,idqr=item).delete()
                                       return render(request, 'poll_app/queries_section.html', context)
                         
                         
                         
                    
     context={"title":name};
     return render(request, 'poll_app/finish.html', context)



def separatePolls(polls):
    active_polls=[]
    completed_polls=[]
    current_datetime= datetime.now()
   
    for i in range(len(polls)):
        start_datetime=polls[i].start_date
        end_datetime=polls[i].end_date
        #print(start_datetime)
        #print(current_datetime)
        #print(end_datetime)
        #print("-----------")
        if(start_datetime<current_datetime and current_datetime<=end_datetime):
            active_polls.append(polls[i])
        else:
             if(start_datetime<current_datetime and current_datetime>end_datetime):
                     completed_polls.append(polls[i])
    context={"active_polls":active_polls,"completed_polls":completed_polls}
    return context

def search_bar(request):
    if request.method=='POST':

        search_text=request.POST['txtSearch']
    else:
        search_text=''
    field=request.POST['selection']
   
    if(field=='name'):
        polls=Polls.objects.filter(name__icontains=search_text)
    else:
         if(field=='description'):
                polls=Polls.objects.filter(description__icontains=search_text)

    return render(request,'poll_app/ajax_search.html',{'polls':polls})



def search_submit(request):
     form= SearchPollForm(request.POST or None)
     print(request.POST)
     print("DEBUG:"+str(form.errors))
     if form.is_valid():
          selection = form.cleaned_data['selection']
          if(selection=='name'):
                    txtSearch = form.cleaned_data['txtSearch']
                    polls=Polls.objects.filter(name__icontains=txtSearch)
          else:
                if(selection=='description'):
                    txtSearch = form.cleaned_data['txtSearch']
                    polls=Polls.objects.filter(description__icontains=txtSearch)
                else:
                    
            
                    if(selection=='category'):
                         category_selection = form.cleaned_data['category_selection']
                        
                         polls=Polls.objects.filter(category=category_selection)
                    else:
                        context={"error_message":"There is a problem. Poll Search failed"}
                        return render(request, 'poll_app/search_poll.html', context)

          
          context=separatePolls(polls) 
         # print(context)
          #a=context['active_polls']
          #for item in a:
          #    print(a)
          return render(request, 'poll_app/search_results.html', context)
     else:
        context={"error_message":"There is a problem. Poll Search failed"}
        return render(request, 'poll_app/search_poll.html', context)




def answer_poll(request):
    
    try:
        poll_name=request.POST["poll_name"]
        poll=Polls.objects.get(name=poll_name)
    
        idp=poll.idp
        #ecxclude queries and range queries with expired true
        idqs=QueriesOfPolls.objects.filter(idp=idp).exclude(expired=True)
        idqrs=RangeQueriesStatistics.objects.filter(idp=idp).exclude(expired=True)
   
        answer_sheet=[]
        
        for item in idqs:
        
            query=Queries.objects.get(pk=(item.idq).idq)
            answers=AnswersOfQueries.objects.filter(idp=idp,idq=query.idq)
            apantiseis=[]
            for ap in answers:
                apantiseis.append(ap.answer)

            question_info={"query":query.query,"type":query.number_answers,"answers":apantiseis}
            answer_sheet.append(question_info)
        print(answer_sheet)
        range_queries=[]
        for item in idqrs:
            range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
            range_queries.append(range_query)
   
        context={"title":poll_name,"answer_sheet":answer_sheet,"range_queries":range_queries}
        return render(request, 'poll_app/answer_poll.html', context)  
    except:
         context={"error_message":"There is a problem. Answer sheet for this poll cannot been loaded"}
         return render(request, 'poll_app/search_results.html', context)




from django.views.decorators.csrf import csrf_exempt







@csrf_exempt
def autoanswer(request):
    #m_answers=request.POST["answers"]
    try:
     code=int(request.POST["id"])
    except:
        code=-1
    try:
        toq=request.POST["toq"]
    except:
        toq=""
    try:
         sel_answer=request.POST["answer"];
    except:
        sel_answer=""
   # sel_answer=float(request.POST["answer"])#change to float or string if  needed
    try: 
       distribution=request.POST["distribution"]
       elements=distribution.split(",")
       elements = [ int(x) for x in elements ]
    except:
          elements=[]

   # sel_answer=float(request.POST["answer"])#change to float or string if  needed
    z=1.96
    try:

        #extract parameters
        poll_name=request.POST["poll_name"]
        print(poll_name)
        n=int(request.POST["sample_size"])

    except:
        response={"state":"fail args"}
        return JsonResponse(response)



    try:
            poll=Polls.objects.get(name=poll_name)
    except  Polls.DoesNotExist:
             response={"state":"fail to find poll"}
             return JsonResponse(response)
    idp=poll.idp
    init_votes=poll.votes
    print(init_votes)
    #vote threshold
    if code!=-1 and len(elements)!=0 and toq=="query":
         bquery=Queries.objects.get(pk=code)
         banswers=AnswersOfQueries.objects.filter(idp=idp,idq=code)
         answer_list=[]
         for m2 in range(len(banswers)):
                   for m3 in  range(elements[m2]):
                                answer_list.append(banswers[m2].answer)

    if code!=-1 and len(elements)!=0 and toq=="range_query":
        brquery=RangeQueries.objects.get(pk=code)
        range1=(brquery.max_val-brquery.min_val)/brquery.step_val
        value_list=[]
        dp=finddecimalpointcount(brquery.step_val)

        for r in arange(brquery.min_val,brquery.max_val+brquery.step_val,brquery.step_val):
            r1=truncatenum(r,dp)
            value_list.append(r1)
            #print(r1)

        answer_list=[]
        if (range1<=10):
                         for m2  in range(len(value_list)):
                             for m3 in  range(elements[m2]):
                                 answer_list.append(value_list[m2])
        else:
                      step=((brquery.max_val-brquery.min_val)/10)
                      
                      if(brquery.type=="integer"):
                             step=int(step)+1
                      limit_up=brquery.min_val+step
                      limit_down=brquery.min_val
                      subvaluelist=[]
                      subvaluelists=[]
                      for m2 in arange(brquery.min_val,brquery.max_val+step,step):
                              
                               if(limit_up==brquery.max_val):
                                    subvaluelist=[x for x in value_list if  x>=limit_down and x<=limit_up]
                                    print(subvaluelist)
                                    subvaluelists.append(subvaluelist)
                               else:
                                  subvaluelist=[x for x in value_list if  x>=limit_down and x<limit_up]
                                  subvaluelists.append(subvaluelist)
                               limit_down=limit_down+step
                               limit_up=limit_up+step
                


                    
                      
                      for m2 in range(len(subvaluelists)):
                               for m3 in range(elements[m2]):
                                   
                                  selection=randint(0,len(subvaluelists[m2])-1)
                                  answer_list.append(subvaluelists[m2][selection])
                      
                                  
    if (code!=-1 and sel_answer!=""):
        answer_list=[]
        for i in range(n):
            answer_list.append(sel_answer)
    #print("len:"+str(len(answer_list)))
    #x=Counter(answer_list)
    #print(x)
    b=[]
    for i in range(n):
     print("l2:"+str(i))
     #idqs=QueriesOfPolls.objects.filter(idp=idp)
     idqs=QueriesOfPolls.objects.filter(idp=idp).exclude(expired=True)
     idqrs=RangeQueriesStatistics.objects.filter(idp=idp).exclude(expired=True)
     lenqs=len(idqs)
     lenqrs=len(idqrs)
     countqs=0
     countqrs=0
     queries=[]
     #    #collect poll questions  for which  answers confident intervals are overlapping -not having conclusion

     for item in idqs:
            
          

            query=Queries.objects.get(pk=(item.idq).idq)
            answers=AnswersOfQueries.objects.filter(idp=idp,idq=query.idq)
           
            apantiseis=[]
            total=item.qvotes
            count=0
            conf_list=[]
            if(query.number_answers=='only one answer'):
             for ap in answers:
                #apantiseis.append(ap.answer)
                conf_int=calc_confidence_interval(ap.percentage,total,z)
                l1=[conf_int['limit_down'],count]
                l2=[conf_int['limit_up'],count]
                conf_list.append(l1)
                conf_list.append(l2)
                count=count+1
                apantiseis.append(ap)

             conf_arr=array(conf_list)
             conf_arr=conf_arr[conf_arr[:,0].argsort()]
             ids=conf_arr[:,1]
           
             show=True
             for j in range(0,len(ids),2):
                 if ids[j]!=ids[j+1]:
                    show=False
                    break
                    #if ids[j]!=ids[j+1]:
                    #         val=conf_arr[j+1,0]
                    #         indexes=where(conf_arr[:,0] == val)
                    #         for k in range(size(indexes,1)):
                    #             if(indexes[0][k]!=j+1):
                    #                if(ids[indexes[0][k]]!=ids[j]):
                    #                        show=False
                    #                else:
                    #                        show=True
                    #         if (show==False):
                    #                    break
             if show==False or total==0:
                     question_info={"query":query.idq,"type":query.number_answers,"answers":apantiseis,"qp":item}
                     queries.append(question_info)
             else:
                countqs=countqs+1
                item.expired=True
                item.save()
                continue
            else:
                if(query.number_answers=='many answers'):
                     show=True
                     
                     recor={}
                     for ap in answers:
                          apantiseis.append(ap)
                          if show==False:
                              continue
                          conf_int=calc_confidence_interval(ap.percentage,total,z)
                          l1=[conf_int['limit_down'],0]
                          l2=[conf_int['limit_up'],0]
                          recor[ap.answer]=conf_int
                          conf_list.append(l1)
                          conf_list.append(l2)
                          conf_int=calc_confidence_interval(1-ap.percentage,total,z)
                          l1=[conf_int['limit_down'],1]
                          l2=[conf_int['limit_up'],1]
                          recor["not "+ap.answer]=conf_int
                          
                          conf_list.append(l1)
                          conf_list.append(l2)
                          conf_arr=array(conf_list)
                          conf_arr=conf_arr[conf_arr[:,0].argsort()]
                          ids=conf_arr[:,1]
                          for j in range(0,len(ids),2):
                                if ids[j]!=ids[j+1]:
                                    show=False
                                    
                          conf_list=[]
                     
                     for keys,values in recor.items():
                                print(keys)
                                print(values)
                                
                     if show==False or total==0:
                         question_info={"query":query.idq,"type":query.number_answers,"answers":apantiseis,"qp":item}
                         queries.append(question_info)
                     else:
                            countqs=countqs+1
                            item.expired=True
                            item.save()
                            continue
        #else:
     range_queries=[]
     for item in idqrs:
          range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
          range_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr)
          dp=finddecimalpointcount(range_query.step_val)
          total=item.qvotes
          count=0
          conf_list=[]
          if(range_query.number_answers=='only one answer'):
            range1=(range_query.max_val-range_query.min_val)/range_query.step_val
            if(range1<=10):
                        for k in arange(range_query.min_val,range_query.max_val+range_query.step_val,range_query.step_val):
                            aswr=truncatenum(k,dp)
                            try:
                                answer=AnswersOfRangeQueries.objects.get(idp=idp,idqr=(item.idqr).idqr,answer=aswr)
                                conf_int=calc_confidence_interval(answer.percentage,total,z)
                            except  AnswersOfRangeQueries.DoesNotExist:
                                conf_int=calc_confidence_interval(0.0,total,z)
                            l1=[conf_int['limit_down'],count]
                            l2=[conf_int['limit_up'],count]
                            conf_list.append(l1)
                            conf_list.append(l2)
                            count=count+1
            else:
                        step=((range_query.max_val-range_query.min_val)/10)
                        if(range_query.type=="integer"):
                             step=int(step)+1
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for k in arange(range_query.min_val,range_query.max_val+step,step):
                            if(limit_up==range_query.max_val):
                                 countr=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr,answer__lte=limit_up,answer__gte=limit_down).aggregate(Sum('count'))
                            else:
                                countr=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr,answer__lt=limit_up,answer__gte=limit_down).aggregate(Sum('count'))
                            if countr['count__sum']==None:
                                countr['count__sum']=0
                            if total!=0:
                                percentage=countr['count__sum']/total 
                            else:
                                 percentage=0
                            conf_int=calc_confidence_interval(percentage,total,z)
                            l1=[conf_int['limit_down'],count]
                            l2=[conf_int['limit_up'],count]
                            conf_list.append(l1)
                            conf_list.append(l2)
                            count=count+1
                            limit_down=limit_down+step
                            limit_up=limit_up+step
          else:
               for k in arange(range_query.min_val,range_query.max_val+range_query.step_val,range_query.step_val):
                            aswr=truncatenum(k,dp)
                            try:
                                answer=AnswersOfRangeQueries.objects.get(idp=idp,idqr=(item.idqr).idqr,answer=aswr)
                                #queries votes
                                rst=RangeQueriesStatistics.objects.get(idp=idp,idqr=(item.idqr).idqr)
                                conf_int=calc_confidence_interval(answer.percentage,total,z)
                            except  AnswersOfRangeQueries.DoesNotExist:
                                 #queries votes
                                 conf_int=calc_confidence_interval(0,total,z)
                            l1=[conf_int['limit_down'],count]
                            l2=[conf_int['limit_up'],count]
                            conf_list.append(l1)
                            conf_list.append(l2)
                            count=count+1
          conf_arr=array(conf_list)
          #print(conf_arr)
          #print("-------------------------")
          conf_arr=conf_arr[conf_arr[:,0].argsort()]
          ids=conf_arr[:,1]
          print(conf_arr)
          #print("-------------------------")
          show=True
          for j in range(0,len(ids),2):
                    if ids[j]!=ids[j+1]:
                        show=False
                        break
                        #val=conf_arr[j+1,0]
                        #indexes=where(conf_arr[:,0] == val)
                        #for k in range(size(indexes,1)):
                        #     if(indexes[0][k]!=j+1):
                        #        if(ids[indexes[0][k]]!=ids[j]):
                        #                    show=False
                        #        else:
                        #                     show=True
                        #if (show==False):
                        #        break
          if show==False  or total==0:
            question_info={"rangequery":range_query,"rst":item}
            range_queries.append(question_info)
         
          else:
                countqrs=countqrs+1
                item.expired=True
                item.save()
                continue
     context={"title":poll_name,"queries":queries,"range_queries":range_queries}
     #for checking
     #if n==1:
         
     #    response={"show":show,"a":len(range_queries)}
     #    #response={"poll_name":poll_name,"sample_size":n,"state":"ok","q":[str(item)for item in queries],"r":[str(item) for item in range_queries],"s":recor}
     #    return JsonResponse(response)
    
     




     if(countqs==lenqs and countqrs==lenqrs):
        print("end")
        poll.end_date=timezone.now()
        poll.save()
        break;
     #if n==1:
         
     #    response={"show":show,"a":len(range_queries)}
     #    #response={"poll_name":poll_name,"sample_size":n,"state":"ok","q":[str(item)for item in queries],"r":[str(item) for item in range_queries],"s":recor}
     #    return JsonResponse(response)
     #produce auto  answers
     #for i in range(n):
     
     for query_set in queries:
               typequery=query_set["type"]
               answers=query_set['answers']
               qp=query_set['qp']
               if typequery=='only one answer': 
                   if(query_set['query']==code):
                        sel_answer=answer_list[i]
                        #print("l1:"+str(i))
                        #b.append(sel_answer)
                        m=[n1 for n1,x in enumerate(answers) if x.answer == sel_answer]
                        idx=m[0]
                   else:
                        idx=randint(1,len(answers))
                   #if(query_set['query']==1017):
                      
                   #    m=[i for i,x in enumerate(answers) if x.answer == 'Yes']
                   #    idx=m[0]
                   #elif (query_set['query']==1019):
                   #     m=[i for i,x in enumerate(answers) if x.answer == 'Special places for Smokers']
                   #     idx=m[0]
                   #elif (query_set['query']==1018):

                   #    m=[i for i,x in enumerate(answers) if x.answer == 'twisted cigarettes']
                   #    idx=m[0]

                   #else:
                   #     idx=randint(1,len(answers))
                   #idx=randint(1,len(answers))
                   answers[idx].count=answers[idx].count+1
                   answers[idx].save()
                   total=AnswersOfQueries.objects.filter(idp=idp,idq=query_set['query']).aggregate(Sum('count'))            
                   for a in answers:
                         a.percentage=a.count/total['count__sum'] 
                         a.save()
                  
                   qp.qvotes=qp.qvotes+1
                   qp.save()
                   qn=Queries.objects.get(idq=query_set['query'])
                   qas=AnswersSeqQueries(idp=poll,idq=qn,answer=answers[idx].answer)
                   qas.save()
               else:
                    if typequery=='many answers':
                        numanswer=randint(1,len(answers))
                        given_answers=[]
                        noanswers=0
                        while(noanswers<numanswer):
                            idx=randint(1,len(answers))
                            if(idx in given_answers):
                                continue
                            else:
                                answers[idx].count=answers[idx].count+1
                                answers[idx].save()
                                given_answers.append(idx)
                                qn=Queries.objects.get(idq=query_set['query'])
                                qas=AnswersSeqQueries(idp=poll,idq=qn,answer=answers[idx].answer)
                                qas.save()
                                #total=AnswersOfQueries.objects.filter(idp=idp,idq=query_set['query']).aggregate(Sum('count'))            
                                for a in answers:
                                     a.percentage=a.count/(qp.qvotes+1)
                                     a.save()
                                noanswers=noanswers+1
                        qp.qvotes=qp.qvotes+1
                        qp.save()
                                
     for query_set in range_queries:
                      range_query=query_set["rangequery"]
                      typequery=range_query.number_answers
                      rst=query_set['rst']
                      min_val=float(range_query.min_val)
                      max_val=float(range_query.max_val)
                      step_val=float(range_query.step_val)
                      range_val=(max_val-min_val)/step_val
                      if typequery=='only one answer':
                        if(range_query.idqr==code):
                             sel_answer=answer_list[i]
                             rangeanswer_val=sel_answer;
                        else:
                            idx=randint(0, range_val+1)
                            rangeanswer_val=min_val+idx*step_val
                        #idx=randint(0, range_val+1)
                        #rangeanswer_val=min_val+idx*step_val
                        try:
                             rangeanswer_record,created=AnswersOfRangeQueries.objects.get_or_create(idp=poll,idqr=range_query,answer=rangeanswer_val,count=1,percentage=0)
    
                        except IntegrityError:
                              rangeanswer_record=AnswersOfRangeQueries.objects.get(idp=poll,idqr=range_query,answer=rangeanswer_val)
                              rangeanswer_record.count= rangeanswer_record.count+1
                        rangeanswer_record.save()
                        other_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr)
                        population=[]
                        for a in other_answers:
                            for l in range(a.count):
                                population.append(a.answer)
                        mean_val=mean(population)
                        std_val=pstdev(population)
                        rst.avg=mean_val
                        rst.std=std_val
                        rst.qvotes=rst.qvotes+1
                        rst.save()
                        qasr=AnswersSeqRangeQueries(idp=poll,idqr=range_query,answer=rangeanswer_val)
                        qasr.save()
                        total=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr).aggregate(Sum('count'))
                        for a in other_answers:
                                a.percentage=a.count/total['count__sum'] 
                                a.save() 
                      else:
                            if typequery=='many answers':
                                 numanswer=randint(1,range_val+1)
                                 given_answers=[]
                                 noanswers=0
                                 while(noanswers<numanswer):
                                    idx=randint(0,range_val+1)
                                    if(idx in given_answers):
                                            continue
                                    else:
                                        rangeanswer_val=min_val+idx*step_val
                                        try:
                                            rangeanswer_record,created=AnswersOfRangeQueries.objects.get_or_create(idp=poll,idqr=range_query,answer=rangeanswer_val,count=1,percentage=0)
    
                                        except IntegrityError:
                                            rangeanswer_record=AnswersOfRangeQueries.objects.get(idp=poll,idqr=range_query,answer=rangeanswer_val)
                                            rangeanswer_record.count= rangeanswer_record.count+1
                                        rangeanswer_record.save()
                                        given_answers.append(idx)
                                        other_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr)
                                        population=[]
                                        for a in other_answers:
                                            for l in range(a.count):
                                                population.append(a.answer)
                                        mean_val=mean(population)
                                        std_val=pstdev(population)
                                        rst.avg=mean_val
                                        rst.std=std_val
                                       
                                        rst.save()
                                        qasr=AnswersSeqRangeQueries(idp=poll,idqr=range_query,answer=rangeanswer_val)
                                        qasr.save()
                                        #total=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr).aggregate(Sum('count'))
                                        for a in other_answers:
                                            a.percentage=a.count/(rst.qvotes+1)
                                            a.save() 

                                        noanswers=noanswers+1
                                 rst.qvotes=rst.qvotes+1
                                 rst.save()
    
     
     
    poll.votes=poll.votes+n
    poll.save()
    print("len:"+str(len(b)))
    x=Counter(b)
    print(x)

    sample_size=poll.votes-init_votes
    response={"poll_name":poll_name,"sample_size":sample_size,"state":"ok"}
    return JsonResponse(response)
  

@csrf_exempt
def deletedata(request):
    try:

        #extract parameters
        poll_name=request.POST["poll_name"]
    except:
        response={"state":"fail args"}
        return JsonResponse(response)
    try:
            poll=Polls.objects.get(name=poll_name)
    except  Polls.DoesNotExist:
             response={"state":"fail to find poll"}
             return JsonResponse(response)
    idp=poll.idp
    poll.votes=0
    d = datetime(2021, 10, 9, 23, 55, 59, 342380) 
    poll.end_date=d
    poll.save()
    idqs=QueriesOfPolls.objects.filter(idp=idp)
    idqrs=RangeQueriesStatistics.objects.filter(idp=idp)
    idaq=AnswersOfQueries.objects.filter(idp=idp)
   
    for item in idqs:
        item.qvotes=0
        item.expired=False
        item.save()
    for item in idqrs:
        item.qvotes=0
        item.expired=False
        item.avg=0.0
        item.std=0.0
        item.save()
    for item in idaq:
        item.count=0
        item.percentage=0.0
        item.save()
    AnswersSeqQueries.objects.filter(idp=idp).delete()
    AnswersSeqRangeQueries.objects.filter(idp=idp).delete()
    AnswersOfRangeQueries.objects.filter(idp=idp).delete()
    response={"delete":"completed"}
    return JsonResponse(response)


#def checkzscore(pa,pb,na,nb):
#    #print(pa)
#    #print(pb)
#    #print(na)
#    #print(nb)
#    if (pa==0 or  pb==0 or na==0 or nb==0):
#            return  False
#    numerator=abs(pa-pb)
#    p1=pa*(1-pa)
#    p2=pb*(1-pb)
#    n1=p1/na
#    n2=p2/nb
#    n=n1+n2
#    denominator=sqrt(n)
#    z_score=numerator/denominator
#    #alpha=0.05,k=2,threshold=2.1783
#    #thresholds=[1.96,2.1783,2.2894,2.3613,2.4131,2.4532,2.4854,2.5123,2.5352,2.555,2.5724,2.5879,2.6019,2.6145,2.6261,2.6367,2.6465,2.6556,2.664,2.672,1.6794,2.6864,2.693,2.6993,2.7052]
#    threshold=2.1783
#    print(z_score)
#    if (z_score>threshold):
#        return True
#    else:
#        return False



       
@csrf_exempt
def responsetest(request):
    try:
     code=int(request.POST["id"])

    except:
        code=-1
    try:
        toq=request.POST["toq"]
    except:
        toq=""
    try:
         sel_answer=request.POST["answer"];
    except:
        sel_answer=""
   # sel_answer=float(request.POST["answer"])#change to float or string if  needed
    try: 
       distribution=request.POST["distribution"]
       elements=distribution.split(",")
       elements = [ int(x) for x in elements ]
    except:
          elements=[]


    try:

        #extract parameters
        poll_name=request.POST["poll_name"]
        print(poll_name)
        n=int(request.POST["sample_size"])

    except:
        response={"state":"fail args"}
        return JsonResponse(response)

    #response={"state":"fail args"}
    #return JsonResponse(response)
    try:
            poll=Polls.objects.get(name=poll_name)
    except  Polls.DoesNotExist:
             response={"state":"fail to find poll"}
             return JsonResponse(response)
    idp=poll.idp
    init_votes=poll.votes
    #vote threshold
   
    if code!=-1 and len(elements)!=0 and toq=="query":
        
         bquery=Queries.objects.get(pk=code)
         banswers=AnswersOfQueries.objects.filter(idp=idp,idq=code)
         answer_list=[]
         for m1 in range(2):
            for m2 in range(len(banswers)):
                   for m3 in  range(elements[m2]):
                                answer_list.append(banswers[m2].answer)

    if code!=-1 and len(elements)!=0 and toq=="range_query":
        brquery=RangeQueries.objects.get(pk=code)
        range1=(brquery.max_val-brquery.min_val)/brquery.step_val
        value_list=[]
        dp=finddecimalpointcount(brquery.step_val)

        for r in arange(brquery.min_val,brquery.max_val+brquery.step_val,brquery.step_val):
            r1=truncatenum(r,dp)
            value_list.append(r1)
            #print(r1)

        answer_list=[]
        if (range1<=10):
            
           
             for m1 in range(2):
                         for m2  in range(len(value_list)):
                             for m3 in  range(elements[m2]):
                                 answer_list.append(value_list[m2])
        else:
                      step=((brquery.max_val-brquery.min_val)/10)
                      if(brquery.type=="integer"):
                             step=int(step)+1
                      limit_up=brquery.min_val+step
                      limit_down=brquery.min_val
                      subvaluelist=[]
                      subvaluelists=[]
                      for m2 in arange(brquery.min_val,brquery.max_val+step,step):
                              
                               if(limit_up==brquery.max_val):
                                    subvaluelist=[x for x in value_list if  x>=limit_down and x<=limit_up]
                                    print(subvaluelist)
                                    subvaluelists.append(subvaluelist)
                               else:
                                  subvaluelist=[x for x in value_list if  x>=limit_down and x<limit_up]
                                  subvaluelists.append(subvaluelist)
                               limit_down=limit_down+step
                               limit_up=limit_up+step
                


                    
                      for m1 in range(2):
                           for m2 in range(len(subvaluelists)):
                               for m3 in range(elements[m2]):
                                   
                                  selection=randint(0,len(subvaluelists[m2])-1)
                                  answer_list.append(subvaluelists[m2][selection])
                           
                           
    #print("len:"+str(len(answer_list)))
    #x=Counter(answer_list)
    #print(x)
    svotes=160
    csvotes=svotes/2
    #response={"done":"ok"}
    #return JsonResponse(response)
    for counter in range(n):
       
        idqs=QueriesOfPolls.objects.filter(idp=idp).exclude(expired=True)
        idqrs=RangeQueriesStatistics.objects.filter(idp=idp).exclude(expired=True)
        lenqs=len(idqs)
        lenqrs=len(idqrs)
        countqs=0
        countqrs=0
        queries=[]
        for item in idqs:
            query=Queries.objects.get(pk=(item.idq).idq)
            answers=AnswersOfQueries.objects.filter(idp=idp,idq=query.idq)
            apantiseis=[]
            for ap in answers:
               apantiseis.append(ap)
               question_info={"query":query.idq,"type":query.number_answers,"answers":apantiseis,"qp":item}
            queries.append(question_info)
        range_queries=[]
        for item in idqrs:
            range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
            question_info={"rangequery":range_query,"rst":item}
            range_queries.append(question_info)
        for query_set in queries:
               typequery=query_set["type"]
               answers=query_set['answers']
               qp=query_set['qp']
              
               if typequery=='only one answer': 
                   
                   if(query_set['query']==code):
                        
                        sel_answer=answer_list[counter]
                        m=[i for i,x in enumerate(answers) if x.answer == sel_answer]
                        idx=m[0]
                   else:
                        idx=randint(1,len(answers))
                   #idx=randint(1,len(answers))
                   answers[idx].count=answers[idx].count+1
                   answers[idx].save()
                   total=AnswersOfQueries.objects.filter(idp=idp,idq=query_set['query']).aggregate(Sum('count'))
                   for a in answers:
                         a.percentage=a.count/total['count__sum'] 
                         a.save()
                   qp.qvotes=qp.qvotes+1
                   qp.save()
                   qn=Queries.objects.get(idq=query_set['query'])
                   qas=AnswersSeqQueries(idp=poll,idq=qn,answer=answers[idx].answer)
                   qas.save()
               else:
                   if typequery=='many answers':
                        numanswer=randint(1,len(answers))
                        given_answers=[]
                        noanswers=0
                        while(noanswers<numanswer):
                            idx=randint(1,len(answers))
                            if(idx in given_answers):
                                continue
                            else:
                                answers[idx].count=answers[idx].count+1
                                answers[idx].save()
                                given_answers.append(idx)
                                qn=Queries.objects.get(idq=query_set['query'])
                                qas=AnswersSeqQueries(idp=poll,idq=qn,answer=answers[idx].answer)
                                qas.save()
                                #total=AnswersOfQueries.objects.filter(idp=idp,idq=query_set['query']).aggregate(Sum('count'))            
                                for a in answers:
                                     a.percentage=a.count/(qp.qvotes+1)
                                     a.save()
                                noanswers=noanswers+1
                        qp.qvotes=qp.qvotes+1
                        qp.save()

    
        
        for query_set in range_queries:
                      range_query=query_set["rangequery"]
                      typequery=range_query.number_answers
                      rst=query_set['rst']
                      min_val=float(range_query.min_val)
                      max_val=float(range_query.max_val)
                      step_val=float(range_query.step_val)
                      range_val=(max_val-min_val)/step_val
                      if typequery=='only one answer':
                        if(range_query.idqr==code):
                             sel_answer=answer_list[counter]
                             rangeanswer_val=sel_answer;
                        else:
                            idx=randint(0, range_val+1)
                            rangeanswer_val=min_val+idx*step_val
                        #idx=randint(0, range_val+1)
                        #rangeanswer_val=min_val+idx*step_val
                        try:
                             rangeanswer_record,created=AnswersOfRangeQueries.objects.get_or_create(idp=poll,idqr=range_query,answer=rangeanswer_val,count=1,percentage=0)
    
                        except IntegrityError:
                              rangeanswer_record=AnswersOfRangeQueries.objects.get(idp=poll,idqr=range_query,answer=rangeanswer_val)
                              rangeanswer_record.count= rangeanswer_record.count+1
                        rangeanswer_record.save()
                        #print(rangeanswer_record)
                        other_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr)
                        population=[]
                        for a in other_answers:
                            for i in range(a.count):
                                population.append(a.answer)
                        mean_val=mean(population)
                        std_val=pstdev(population)
                        rst.avg=mean_val
                        rst.std=std_val
                        rst.qvotes=rst.qvotes+1
                        rst.save()
                       
                        total=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr).aggregate(Sum('count'))
                        for a in other_answers:
                                a.percentage=a.count/total['count__sum'] 
                                a.save() 
                        qasr=AnswersSeqRangeQueries(idp=poll,idqr=range_query,answer=rangeanswer_val)
                        qasr.save()
                      else:
                          if typequery=='many answers':
                                 numanswer=randint(1,range_val+1)
                                 given_answers=[]
                                 noanswers=0
                                 while(noanswers<numanswer):
                                    idx=randint(0,range_val+1)
                                    if(idx in given_answers):
                                            continue
                                    else:
                                         rangeanswer_val=min_val+idx*step_val
                                         try:
                                            rangeanswer_record,created=AnswersOfRangeQueries.objects.get_or_create(idp=poll,idqr=range_query,answer=rangeanswer_val,count=1,percentage=0)
    
                                         except IntegrityError:
                                            rangeanswer_record=AnswersOfRangeQueries.objects.get(idp=poll,idqr=range_query,answer=rangeanswer_val)
                                            rangeanswer_record.count= rangeanswer_record.count+1
                                         rangeanswer_record.save()
                                         given_answers.append(idx)
                                         other_answers=AnswersOfRangeQueries.objects.filter(idp=idp,idqr=range_query.idqr)
                                         population=[]
                                         for a in other_answers:
                                            for i in range(a.count):
                                                population.append(a.answer)
                                         mean_val=mean(population)
                                         std_val=pstdev(population)
                                         rst.avg=mean_val
                                         rst.std=std_val
                                       
                                         rst.save()
                                         qasr=AnswersSeqRangeQueries(idp=poll,idqr=range_query,answer=rangeanswer_val)
                                         qasr.save()
                                         for a in other_answers:
                                            print(a.idp+"|"+a.idqr+"|"+a.count+"|"+a.percentage)
                                            a.percentage=a.count/(rst.qvotes+1)
                                            a.save() 
                                         
                                         noanswers=noanswers+1
                                 rst.qvotes=rst.qvotes+1
                                 rst.save()

        
        for item in idqs:
            qvotes=item.qvotes
            
            if(qvotes%svotes==0 and qvotes>=svotes):
                             
                             print("A/B")
                             answers_count= AnswersOfQueries.objects.filter(idp=idp,idq=(item.idq).idq).count()
                             samples_record=AnswersSeqQueries.objects.filter(idp=idp,idq=(item.idq).idq).order_by('-idas')[0:svotes]
                             for i in range(0,2):
                                 print(str(i+1)+"/2")
                                 team=samples_record[i*csvotes:(i+1)*csvotes]
                                 answer_items=[]
                                 for itemx in team:
                                     answer_items.append(itemx.answer)
                                 samples_datac=Counter(answer_items)
                                 samples_datacount=[]
                                 samples_datapercentage=[]
                                 for value in samples_datac.items():
                                     samples_datacount.append(value[1])
                                     percentage=value[1]/csvotes
                                     samples_datapercentage.append(percentage)
                                 noanaswers=answers_count-len(samples_datacount)
                                 #print(samples_datacount)
                                 #print(samples_datapercentage)
                                 #print(noanaswers)
                                 for j in range(noanaswers):
                                     samples_datacount.append(0)
                                     samples_datapercentage.append(0)
                                 checkz=True
                                 for k1 in range(len(samples_datacount)):
                                     
                                     for k2 in range(k1+1,len(samples_datacount)):
                                         print("z"+str(k1)+str(k2))

                                         checkz=checkzscore(samples_datapercentage[k1],samples_datapercentage[k2],samples_datacount[k1],samples_datacount[k2])
                                         if(checkz==False):
                                                   break
                                     if(checkz==False):
                                                break
                                 if(checkz==False):
                                                break
                             if(checkz==True):
                                 countqs=countqs+1
                                 item.expired=True
                                 item.save()
                                        

    
    
    
    
    
   
        for item in idqrs:
            qvotes=item.qvotes
            if(qvotes%svotes==0 and qvotes>=svotes):
                print("A/B")
                range_query=RangeQueries.objects.get(pk=(item.idqr).idqr)
                range1=(range_query.max_val-range_query.min_val)/range_query.step_val
                samples_record=AnswersSeqRangeQueries.objects.filter(idp=idp,idqr=(item.idqr).idqr).order_by('-idars')[0:svotes]
                if(range1<=10):
                   answers_count=int(range1+1)
                   for i in range(0,2):
                       print(str(i+1)+"/2")
                       team=samples_record[i*csvotes:(i+1)*csvotes]
                       answer_items=[]
                       for itemx in team:
                           answer_items.append(itemx.answer)
                       samples_datac=Counter(answer_items)
                       samples_datacount=[]
                       samples_datapercentage=[]
                       percentage=0
                       for value in samples_datac.items():
                           samples_datacount.append(value[1])
                           percentage=value[1]/csvotes
                           samples_datapercentage.append(percentage)
                       noanaswers=answers_count-len(samples_datacount)
                       for j in range(noanaswers):
                            samples_datacount.append(0)
                            samples_datapercentage.append(0)
                       checkz=True
                       for k1 in range(len(samples_datacount)):
                            if(checkz==False):
                                     break
                            for k2 in range(k1+1,len(samples_datacount)):
                                        print("z"+str(k1)+str(k2))
                                        checkz=checkzscore(samples_datapercentage[k1],samples_datapercentage[k2],samples_datacount[k1],samples_datacount[k2])
                                        if(checkz==False):
                                            break
                       if(checkz==False):
                            break
                else:
                    for i in range(0,2):
                        print(str(i+1)+"/2")
                        team=samples_record[i*csvotes:(i+1)*csvotes]
                        answer_items=[]
                        step=((range_query.max_val-range_query.min_val)/10)
                        if(range_query.type=="integer"):
                             step=int(step)+1
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for itemx in team:
                                answer_items.append(itemx.answer)
                        samples_datacount=[]
                        samples_datapercentage=[]
                        percentage=0
                       
                        limit_up=range_query.min_val+step
                        limit_down=range_query.min_val
                        for nx in arange(range_query.min_val,range_query.max_val+step,step):
                            if(limit_up==range_query.max_val):
                                    count = sum(map(lambda x : x<=limit_up and x>=limit_down, answer_items))
                            else:
                                 count = sum(map(lambda x : x<limit_up and x>=limit_down, answer_items))
                            samples_datacount.append(count)
                            percentage=count/csvotes
                            samples_datapercentage.append(percentage)
                            limit_down=limit_down+step
                            limit_up=limit_up+step
                        checkz=True
                        for k1 in range(len(samples_datacount)):
                            if(checkz==False):
                                break
                            for k2 in range(k1+1,len(samples_datacount)):
                                print("z"+str(k1)+str(k2))
                                checkz=checkzscore(samples_datapercentage[k1],samples_datapercentage[k2],samples_datacount[k1],samples_datacount[k2])
                                if(checkz==False):
                                        break
                        if(checkz==False):
                              break

                if(checkz==True):
                   countqrs=countqrs+1
                   item.expired=True
                   item.save()

         
        if(countqs==lenqs and countqrs==lenqrs):
            print("end")
            poll.end_date=timezone.now()
            poll.save()
            break;
    poll.votes=poll.votes+n
    poll.save()
    sample_size=poll.votes-init_votes
    response={"poll_name":poll_name,"sample_size":sample_size,"state":"ok"}
    return JsonResponse(response)
