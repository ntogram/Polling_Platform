from django.conf.urls import url;
from django.contrib import admin;
from poll_app import views
#/music
app_name='poll_app'
urlpatterns = [url(r'^$',views.homepage,name='homepage'),
url(r'startcreate_poll$',views.show_create_poll,name='show_create_poll'),
url(r'startsearch_poll$',views.show_search_poll,name='show_search_poll'),           
url(r'queries_poll_section$',views.queries_section,name='queries_section'),             
url(r'finish$',views.finish,name='finish'),
url(r'search_bar$',views.search_bar,name='search_bar'),
url(r'search_submit',views.search_submit,name='search_submit'),
url(r'answer_poll',views.answer_poll,name='answer_poll'),
url(r'submit_answers',views.submit_answers,name='submit_answers'),
url(r'show_stats',views.show_stats,name='show_stats'),
url(r'autoanswer',views.autoanswer,name='autoanswer'),

url(r'deletedata',views.deletedata,name='deletedata'),
url(r'responsetest',views.responsetest,name='responsetest')
               ]

