from django.apps import AppConfig


class poll_appConfig(AppConfig):
    name = 'poll_app'
