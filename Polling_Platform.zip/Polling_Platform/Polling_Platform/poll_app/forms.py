﻿from django import forms
from .models import Polls


class CreatePollForm(forms.ModelForm):
    class Meta:
        model= Polls
        fields= ["name", "description", "category", "start_date","end_date"]

class SearchPollForm(forms.Form):
    txtSearch = forms.CharField()
    category_selection = forms.CharField()
    selection = forms.CharField()