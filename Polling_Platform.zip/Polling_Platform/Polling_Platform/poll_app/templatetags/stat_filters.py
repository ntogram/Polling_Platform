from django import template

register = template.Library()
@register.filter(name='make_percentage')
def make_percentage(value):
    return round(float(value)*100,2)


@register.filter(name='cut_float')
def cut_float(value,arg):
    if arg=='range_query':
        new_values=[]
        values=str(value).split("-")
        if len(values)==1 or len(values)==2:
                                 for item in values:
                                     dec=float(item)-int(float(item))
                                     if dec==0:
                                         new_values.append(str(int(float(item))))
                                     else:
                                          new_values.append(item)
                                 new_val=new_values[0]
                                 if (len(new_values)==2):
                                     new_val=new_val+"-"+new_values[1]
                                 return new_val
        else:
                                 return value
        
    else:
                                 return value

                                 
                                        
            
