﻿$(document).ready(function () {
    $('#txtSearch').on('change keyup  paste input', function () {
        $.ajax({
            type: 'POST',
            url: "search_bar",
            data: {
                'txtSearch': $('#txtSearch').val(),
                'selection': $('#selection').val(),
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()

            },
            success: searchSuccess,
            datType: 'html'
        });
    });


    function searchSuccess(data, textStatus, jqXHR) {
        var search_length = ($('#txtSearch').val()).length
        //$('#search-results').append("<li>Appended item</li>")
        $('#search-results').html(data);
        if (search_length >= 2) {
            $(".dropdown").css("display", "block")
            $("#menu1").dropdown("toggle");
        }
        else {
             $(".dropdown").css("display", "none")
        }
        $('#txtSearch').focus();
    }
});



$(document).ready(function () {
    $(document).on('click', '#list_element', function () {
        //alert("mpika")
        (document.getElementsByTagName('input'))[1].value = $(this).text()
        $(".dropdown").css("display", "none")
    })
})




$(document).ready(function () {


    $("#txtSearch").mouseenter(function () {



        var search_length = ($('#txtSearch').val()).length
        //$('#search-results').append("<li>Appended item</li>")

        if (search_length >= 2) {
            $(".dropdown").css("display", "block")
            $("#menu1").dropdown("toggle");
        }
        else {
            $(".dropdown").css("display", "none")
        }
        $('#txtSearch').focus();




    });
    /*
    $("#txtSearch").mouseleave(function () {
        $(".dropdown").css("display", "none")
    })
    */
})