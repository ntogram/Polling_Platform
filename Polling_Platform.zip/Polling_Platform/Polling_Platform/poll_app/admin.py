from django.contrib import admin
from .models import *

admin.site.register(Polls)
admin.site.register(Queries)
admin.site.register(QueriesOfPolls)
admin.site.register(AnswersOfQueries)
admin.site.register(RangeQueries)
admin.site.register(RangeQueriesStatistics)
admin.site.register(AnswersOfRangeQueries)
admin.site.register(AnswersSeqQueries)
admin.site.register(AnswersSeqRangeQueries)

# Register your models here.
