"""
Package for Polling_Platform.
"""
